from django import forms

CROP_CHOICES = [
    ('maize', 'Maize'),
    ('beans', 'Beans'),
    ('potato', 'Potato'),
    ('tomato', 'Tomato'),
    ('watermelon', 'Watermelon'),
    ('kales', 'Kales'),
    ('cabbage', 'Cabbage'),
]

MODE_CHOICES = [
    ('text', 'Text Description'),
    ('image', 'Image Upload'),
]

class PredictionForm(forms.Form):
    crop = forms.ChoiceField(choices=CROP_CHOICES)
    mode = forms.ChoiceField(choices=MODE_CHOICES, widget=forms.RadioSelect)
    description = forms.CharField(widget=forms.Textarea, required=False)
    image = forms.ImageField(required=False)
