from django.shortcuts import render
from .forms import PredictionForm
import torch
import pickle
import os
from PIL import Image
import torchvision.transforms as transforms

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODELS_DIR = os.path.join(BASE_DIR, 'models')

# Example label maps (customize per crop)
LABEL_MAPS = {
    "maize": {
        0: "Blight",
        1: "Common Rust",
        2: "Fall Armyworm",
        3: "Gray Leaf Spot",
        4: "Streak Virus",
        5: "Leaf Beetle",
    },
    "beans": {
        0: "Anthracnose",
        1: "Bacterial Blight",
        2: "Rust",
    },
    # Add for other crops as needed
}

def load_model(crop, mode):
    filename = f"{crop}_{mode}.pkl" if mode == "text" else f"{crop}_{mode}.pt"
    model_path = os.path.join(MODELS_DIR, filename)
    if mode == "text":
        with open(model_path, 'rb') as f:
            return pickle.load(f)
    else:
        return torch.load(model_path, map_location=torch.device('cpu'))

def preprocess_text(text):
    return text.lower()

def preprocess_image(image_file):
    image = Image.open(image_file).convert("RGB")
    transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
    ])
    return transform(image)

def predict_text(model, description):
    processed = preprocess_text(description)
    return model.predict([processed])[0]

def predict_image(model, image_tensor, crop):
    model.eval()
    with torch.no_grad():
        input_tensor = image_tensor.unsqueeze(0)
        outputs = model(input_tensor)
        predicted_idx = outputs.argmax(dim=1).item()
        return LABEL_MAPS.get(crop, {}).get(predicted_idx, "Unknown")

def predict_view(request):
    result = None
    if request.method == 'POST':
        form = PredictionForm(request.POST, request.FILES)
        if form.is_valid():
            crop = form.cleaned_data['crop']
            mode = form.cleaned_data['mode']
            model = load_model(crop, mode)

            if mode == 'text':
                description = form.cleaned_data['description']
                result = predict_text(model, description)
            else:
                image_tensor = preprocess_image(request.FILES['image'])
                result = predict_image(model, image_tensor, crop)
    else:
        form = PredictionForm()

    return render(request, 'detection/predict.html', {
        'form': form,
        'result': result
    })

# Create your views here.
